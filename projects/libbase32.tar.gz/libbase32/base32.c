/*
 * Copyright 2009 by Henry Precheur <henry@precheur.org>
 *
 * Permission to use, copy, modify, and/or distribute this software for any purpose
 * with or without fee is hereby granted, provided that the above copyright notice
 * and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND ISC DISCLAIMS ALL WARRANTIES WITH REGARD TO
 * THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS.
 * IN NO EVENT SHALL ISC BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA
 * OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
 * SOFTWARE.
 */

#include <assert.h>
#include <stdlib.h>

#include "base32.h"

static const char   __base32_encode[] = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
static const char   __base32_decode[] = {
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, -1,
    -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, 16, 17, 1, 18, 19, 1, 20,
    21, 0, 22, 23, 24, 25, 26, -1, 27, 28, 29, 30, 31, -1, -1, -1, -1, -1, -1,
    10, 11, 12, 13, 14, 15, 16, 17, 1, 18, 19, 1, 20, 21, 0, 22, 23, 24, 25, 26,
    -1, 27, 28, 29, 30, 31, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1};

char*   base32_encode_r(int x, char* result) {
    char    buffer[BASE32_STRING_SIZE(x)];
    char*   p = buffer;
    char*   r = result;

    do {
        *p++ = __base32_encode[x & 0x1f];
        x = x >> 5;
    } while (x);

    do {
        *r++ = *--p;
    } while (p != (char*)buffer);
    *r = '\0';
    return result;
}

const char* base32_encode(int x) {
    assert(x >= 0);
    /*
     * Each base 32 character carries 5 bits of information. Add 1 byte for the
     * \0 and one character because integer division round the result to the
     * smaller number:
     *   32.0 / 5 = 6.4 but in C 32 / 5 = 6.
     */
    static char result[BASE32_STRING_SIZE(x)];

    return base32_encode_r(x, result);
}

int base32_decode(const char* str) {
    int result = 0;

    while (*str) {
        char c = __base32_decode[(size_t)*str];

        if (c == -1) {
            return -1;
        } else {
            if (*str != '-') {
                result = result * 32 + c;
            }
            str++;
        }
    }
    return result;
}
