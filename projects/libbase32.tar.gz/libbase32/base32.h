/*
 * Copyright 2009 by Henry Precheur <henry@precheur.org>
 *
 * Permission to use, copy, modify, and/or distribute this software for any purpose
 * with or without fee is hereby granted, provided that the above copyright notice
 * and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND ISC DISCLAIMS ALL WARRANTIES WITH REGARD TO
 * THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS.
 * IN NO EVENT SHALL ISC BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA
 * OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
 * SOFTWARE.
 */

int base32_decode(const char*);

const char* base32_encode(int);
char*   base32_encode_r(int, char*);

/*
 * Return the size of the string --including trailing '\0'-- needed to store x.
 * x can be a variable or a type.
 *
 * Each base 32 character carries 5 bits of information. Add 1 byte for the
 * \0 and one character because integer division round the result to the
 * smaller number:
 *   32.0 / 5 = 6.4 but in C 32 / 5 = 6.
 *
 * The result might a superior to what is actually needed by 1 byte if the
 * type's size in bits is a multiple of 5. This can't happen if all types size
 * are a power of 2.
 */
#define BASE32_STRING_SIZE(x) ((size_t)(((sizeof (x) * 8) / 5) + 2))
