/*
 * Copyright 2009 by Henry Precheur <henry@precheur.org>
 *
 * Permission to use, copy, modify, and/or distribute this software for any purpose
 * with or without fee is hereby granted, provided that the above copyright notice
 * and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND ISC DISCLAIMS ALL WARRANTIES WITH REGARD TO
 * THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS.
 * IN NO EVENT SHALL ISC BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA
 * OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
 * SOFTWARE.
 */

#include <sys/time.h>
#include <err.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "base32.h"

const size_t  LIMIT = 1000 * 1000;

void*   xmalloc(size_t nmemb, size_t size)
{
    void*   p = calloc(nmemb, size);
    if (p == NULL) {
        err(1, NULL);
    }
    return p;
}

time_t  time_it(void) {
    static struct timeval  tv = {.tv_sec = 0, .tv_usec = 0};
    struct timeval  new;
    time_t  result;

    if (gettimeofday(&new, NULL) == -1) {
        err(1, NULL);
    }
    result = ((new.tv_sec - tv.tv_sec) * 1000 +
              (new.tv_usec - tv.tv_usec) / 1000);
    tv = new;
    return result;
}

void time_decode(int (*func)(const char*)) {
    char**  pstr = xmalloc(LIMIT, sizeof (char*));
    char*   buf = xmalloc(LIMIT, sizeof (size_t) * 8 / 5 + 2); /* should be enough :) */
    size_t  i;

    {
        char*   p = buf;

        for (i = 0; i < LIMIT; i++)
        {
            base32_encode_r(i, p);
            pstr[i] = p;
            p += strlen(p) + 1;
        }
    }

    time_it();
    for (i = 0; i < LIMIT; i++)
    {
        func(pstr[i]);
    }
    printf("%dms\n", time_it());
}

void time_encode(char* (*func)(int, char*)) {
    char    buffer[32];
    size_t  i;

    time_it();
    for (i = 0; i < LIMIT; i++) {
        func(i, buffer);
    }
    printf("%dms\n", time_it());
}

const char* __SYMBOLS[256] = {
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    "0Oo", "1IiLl", "2", "3", "4", "5", "6", "7", "8", "9", NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, "Aa", "Bb", "Cc", "Dd", "Ee", "Ff", "Gg", "Hh",
    NULL, "Jj", "Kk", NULL, "Mm", "Nn", NULL, "Pp", "Qq", "Rr", "Ss", "Tt",
    NULL, "Vv", "Ww", "Xx", "Yy", "Zz", NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    NULL, NULL, NULL};

/*
 * Alternate symbols at position p.
 *   If *p == '0', replace *p with '0', 'O', 'o' and recurse with p = p + 1.
 * s and x are constant.
 * If _alternate_symbols reachs the end of the string, it decodes s and makes
 * sure it is equal to x.
 */
void    _alternate_symbols(const char* s, char* p, int x) {
    const char  c = *p;

    if (c == '\0') {
        int y = base32_decode(s);
        if (y != x) {
            err(1, "Error while decoding %s, %d != %d\n", s, y, x);
        }
    } else {
        const char* alt = __SYMBOLS[(unsigned char)c];

        for (alt = __SYMBOLS[(unsigned char)c]; *alt != '\0'; alt++) {
            *p = *alt;
            _alternate_symbols(s, p + 1, x);
        }
        *p = c;
    }
}

void    test_decode_alternative_symbols(int x) {
    char    buffer[BASE32_STRING_SIZE(x)];
    int i;

    for (i = 0; i < x; i++) {
        base32_encode_r(i, buffer);
        _alternate_symbols(buffer, buffer, i);
    }
}

int main()
{
#if 1
    time_encode(base32_encode_r);
#endif
#if 1
    time_decode(base32_decode);
#endif
#if 1
    {
        size_t  i;

        time_it();
        for (i = 0; i < LIMIT; i++)
        {
            const char*   p = base32_encode(i);
            assert((int)i == base32_decode(p));
        }
        printf("%dms\n", time_it());
    }
#endif
#if 1
    test_decode_alternative_symbols(LIMIT);
#endif
    printf("All tests were run succesfully.\n");
    return 0;
}
