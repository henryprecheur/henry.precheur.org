#!/bin/sh

if [ -z "$1" ]
then
        echo "Usage: ${0} URL"
        exit 1
fi

function bench
{
    curl -s -o /dev/null \
        --user-agent 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.20) Gecko/20081217 Firefox/2.0.0.20' \
        -w '%{time_total} %{time_connect} %{time_starttransfer} %{size_download}\n' \
        $*
}

results_dir=.

rm -f *.csv

for i in 0 1 2 3 4 5 6 7 8 9; do
    for j in 0 1 2 3 4 5 6 7 8 9; do
        bench "$*" >> ${results_dir}/no\ gzip.csv
        bench --compress "$*" >> ${results_dir}/gzip.csv
    done
done
