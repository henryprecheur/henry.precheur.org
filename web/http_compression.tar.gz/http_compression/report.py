#!/usr/bin/env python

import os
import math

# Change this to True to get a HTML table
_HTML_REPORT = False

def _time(x):
    return '%d' % (x * 1000)

def _mean(index, seq):
    return sum(float(r[index]) for r in seq) / len(seq)

def _median(index, seq):
    return sorted(float(r[index]) for r in seq)[len(seq) // 2 + 1]

def _standard_deviation(index, seq):
    mean = _mean(index, seq)
    diffs = list(pow(float(r[index]) - mean, 2) for r in seq)
    return math.sqrt(sum(diffs) / len(seq))

def report(filename):
    results = list(line.split() for line in open(filename))
    if _HTML_REPORT:
        print '<tr>\n<th>%s</th>' % os.path.splitext(filename)[0]
        def _report(variable_name, index, dark):
            r = (_time(_mean(index, results)),
                 _time(_median(index, results)))
            if dark:
                print '<td class=dark>%s</td><td class=dark>%s</td>' % r
            else:
                print '<td>%s</td><td>%s</td>' % r
    else:
        print filename
        def _report(variable_name, index, dark):
            print '  %s' % variable_name
            print '    Mean',               _time(_mean(index, results))
            print '    Median',             _time(_median(index, results))
            print '    Standard Deviation', _time(_standard_deviation(index,
                                                                      results))
            print
    _report('Connect time', 1, True)
    _report('Pre-transfer time', 2, False)
    _report('Total time', 0, True)
    size = int(results[0][3])
    if _HTML_REPORT:
        print '<td>%d</td><td>%.02f</td>' % (size, float(size) / 1024)
        print '</tr>'
    else:
        print '  Size %d (%.02f KBytes)' % (size, float(size) / 1024)

if _HTML_REPORT:
    print '<table>'
    print ('<tr>'
           '<th rowspan=2>File</th>'
           '<th colspan=2 class=dark>Connect time</th>'
           '<th colspan=2>Pre-transfer time</th>'
           '<th colspan=2 class=dark>Total time</th>'
           '<th colspan=2>Transfert size</th>'
           '</tr>')
    print ('<tr>'
           '<th class=dark>Mean</th><th class=dark>Median</th>'
           '<th>Mean</th><th>Median</th>'
           '<th class=dark>Mean</th><th class=dark>Median</th>'
           '<th>Bytes</th><th>KBytes</th>'
           '</tr>')

for filename in os.listdir('.'):
    if filename.endswith('.csv'):
        report(filename)

if _HTML_REPORT:
    print '</table>'
