#!/usr/bin/env python
from weblog import main

main()
