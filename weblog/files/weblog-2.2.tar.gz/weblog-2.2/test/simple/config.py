title = 'Test blog'
url = 'http://blog.test.org'
description = 'Test blog'
author = 'test <test@test.org>'
