from cgi import escape

def encode(text, encoding, errors='xmlcharrefreplace'):
    if encoding.lower() == 'raw':
        return text
    else:
        return text.decode(encoding).encode('ascii', errors)

def escape_and_encode(text, encoding, errors='xmlcharrefreplace'):
    if encoding.lower() == 'raw':
        return text
    else:
        return escape(text).decode(encoding).encode('ascii', errors)
