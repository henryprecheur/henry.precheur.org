import os
import sys
import datetime
from ConfigParser import SafeConfigParser, NoOptionError
from jinja import Environment, FileSystemLoader, PackageLoader, ChoiceLoader
from weblog import RSS2, RSSItem, Post, encode

def jinja_environment():
    """
    Build the Jinja environment. Setup all template loaders.
    """
    TEMPLATE_DIR = 'templates'
    fs_loader = FileSystemLoader(TEMPLATE_DIR)
    fs_app_loader = FileSystemLoader(os.path.join(sys.path[0], 'weblog',
                TEMPLATE_DIR))
    pkg_loader = PackageLoader('weblog', TEMPLATE_DIR)
    choice_loader = ChoiceLoader([fs_loader, fs_app_loader, pkg_loader])
    return Environment(loader=choice_loader, trim_blocks=True)

def load_post_list(path):
    post_list = set()
    for post_filename in os.listdir(path):
        if post_filename.endswith('.html'):
            p = Post(os.path.join(path, post_filename))
            if p in post_list:
                duplicated_post_filename = None
                for post in post_list:
                    if post == p:
                        duplicated_post_filename = post._filename
                raise IOError('"%s" There is already a post with this title '
                        'and date ("%s")' % \
                        (post_filename, duplicated_post_filename))
            else:
                post_list.add(p)
    return post_list

def generate_post_html(post_list, output_dir, post_tmpl, base_url):
    for post in post_list:
        def make_dir(dir):
            if os.path.exists(dir):
                if not os.path.isdir(dir):
                    raise IOError('%s exists and is not a directory' % dir)
            else:
                print 'creating directory %s' % dir
                os.mkdir(dir)
        dir = output_dir
        for d in (post.date.year, post.date.month, post.date.day):
            dir = os.path.join(dir, str(d))
            make_dir(dir)
        filename = os.path.join(dir, post.ascii_title + '.html')
        if os.path.exists(filename):
            if not os.path.isfile(filename):
                raise IOError('%s exists and is not a file' % filename)
        output = file(filename, 'w')
        output.write(post_tmpl.render(title=post.title,
                                      base_url=base_url,
                                      top_dir='../../../',
                                      post=post))

def generate_rss(post_list, filename, title, base_url, description):
    rss_items = []
    for post in reversed(sorted(post_list)):
        rss_items.append(
                RSSItem(
                    title=post.title,
                    link=post.url(prefix=base_url),
                    description=post.content,
                    guid=post.url(prefix=base_url),
                    pubDate=datetime.datetime(*(post.date.timetuple()[:3]))))
    rss = RSS2(
        title = title,
        link = base_url,
        description = description,
        lastBuildDate = datetime.datetime.now(),
        items=rss_items)
    rss.write_xml(open(filename, "w"))

def load_configuration(config_file):
    if not os.path.exists(config_file):
        print 'unable to find file %s' % config_file
        exit(1)
    config = SafeConfigParser()
    config.read(config_file)
    return dict(config.items('weblog'))

def main():
# hardcoded configuration file. Might be a good idea to make it customizabe.
    CONFIG_FILE = 'weblog.ini'
    config_dict = load_configuration(CONFIG_FILE)

    try:
        encoding = config_dict.get('encoding', 'ascii')
        blog_title = encode(config_dict['title'], encoding)
        blog_base_url = config_dict['url']
        if blog_base_url and not blog_base_url.endswith('/'):
            blog_base_url += '/'
        blog_description = config_dict['description']
        post_dir = config_dict.get('post_dir', '.')
        output_dir = config_dict.get('output_dir', 'output/')
        author = config_dict.get('author', None)
# add the default author & encoding constant to the post class
        Post.ENCODING = encoding
        if author:
            Post.AUTHOR = author
    except KeyError, e:
        print 'Unable to find %s in configuration file %s' % (e, CONFIG_FILE)
        exit(1)

    if not os.path.exists(output_dir):
        print 'creating %s ...' % output_dir
        os.mkdir(output_dir)

    env = jinja_environment()

    post_list = load_post_list(post_dir)

# generate the main index page
    tmpl = env.get_template('index.html.tmpl')
    output = file(os.path.join(output_dir, 'index.html'), 'w')
    output.write(tmpl.render(title=blog_title,
                base_url=blog_base_url,
                post_list=reversed(sorted(post_list))))

    post_tmpl = env.get_template('post.html.tmpl')
    generate_post_html(post_list, output_dir, post_tmpl, blog_base_url)

    generate_rss(post_list, os.path.join(output_dir, 'rss.xml'),
                 blog_title, blog_base_url, blog_description)

if __name__ == '__main__':
    main()
