import unittest
from weblog_publish import load_post_list

class TestSimpleLoad(unittest.TestCase):

    def test_load_post_list(self):
        post_list = load_post_list('test/simple/')
        self.assertEqual(len(post_list), 3)
        sorted_list = sorted(post_list)
        self.assertEqual(sorted_list[0].title, 'post1')
        self.assertEqual(sorted_list[1].title, 'post2')
        self.assertEqual(sorted_list[2].title, 'post3')

if __name__ == '__main__':
    unittest.main()
