import os
import shutil
import tempfile
import unittest
import StringIO

from weblog import Post, PostError
from weblog import jinja_environment
from weblog_publish import load_post_list, generate_rss, \
     generate_index_listing

class TestSimpleLoad(unittest.TestCase):

    def test_load_post_list(self):
        post_list = load_post_list('test/simple/')
        self.assertEqual(len(post_list), 3)
        sorted_list = sorted(post_list)
        self.assertEqual(sorted_list[0].title, 'post1')
        self.assertEqual(sorted_list[1].title, 'post2')
        self.assertEqual(sorted_list[2].title, 'post3')

    def test_load_post_list_encoding_failure(self):
        Post.ENCODING = 'ascii'
        self.assertRaises(PostError, load_post_list, 'test/encoding/')
    
    def test_load_post_list_encoding(self):
        Post.ENCODING = 'UTF-8'
        post_list = load_post_list('test/encoding/')
        self.assertEqual(len(post_list), 2)
        sorted_list = sorted(post_list)
        self.assertEqual(sorted_list[0].title,
                         'UTF-8 post &#214;&#201;&#200;&#196; ...')
        self.assertEqual(sorted_list[0].content,
                         '&#214;&#233;&#232;&#228;\n')
        self.assertEqual(sorted_list[1].title,
                         'latin post &#214;&#201;&#200;&#196; ...')
        self.assertEqual(sorted_list[1].content,
                         '&#214;&#233;&#232;&#228;\n')

class TestGeneration(unittest.TestCase):

    env = jinja_environment(os.path.dirname(__file__))

    def setUp(self):
        self.tempdir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tempdir)

    def test_generate_listing_empty(self):
        generate_index_listing(10,
                               self.tempdir,
                               self.env.get_template('index.html.tmpl'),
                               list(),
                               dict(title='test',
                                    url='http://test.net',
                                    description='test'))

    def test_generate_listing(self):
        post1 = '''title: post1
date: 2008-02-04

post 1'''
        post2 = '''title: post2
date: 2008-01-18
author: test@test.com

post 2'''
        post_list = [Post(StringIO.StringIO(post1)),
                     Post(StringIO.StringIO(post2))]
        generate_index_listing(10,
                               self.tempdir,
                               self.env.get_template('index.html.tmpl'),
                               post_list,
                               dict(title='test',
                                    url='http://test.net',
                                    description='test'))

    def test_generate_rss(self):
        post1 = '''title: post1
date: 2008-02-04

post 1'''
        post2 = '''title: post2
date: 2008-01-18
author: test@test.com

post 2'''
        post_list = [Post(StringIO.StringIO(post1)),
                     Post(StringIO.StringIO(post2))]
        generate_rss(post_list,
                     os.path.join(self.tempdir, 'rss.xml'),
                     dict(title='test',
                          url='http://test.net',
                          description='test'))

    def test_generate_rss_empty(self):
        generate_rss(list(),
                     os.path.join(self.tempdir, 'rss.xml'),
                     dict(title='test',
                          url='http://test.net',
                          description='test'))

if __name__ == '__main__':
    unittest.main()
