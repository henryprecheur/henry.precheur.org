Weblog's documentation
======================

.. include:: short_description.txt

To get news and updates about Weblog check the author's blog:
  http://henry.precheur.org/
or check Weblog's homepage:
  http://henry.precheur.org/weblog/

Contents

.. toctree::
   :maxdepth: 2

   install
   tutorial
   reference

* Markdown_ markup language
* :ref:`search`

.. _Markdown: http://daringfireball.net/projects/markdown/syntax#overview
