import os
import datetime
from jinja import Environment, FileSystemLoader
import PyRSS2Gen
from post import Post

BLOG_TITLE = 'Henry\'s weblog'
BLOG_BASE_URL = 'http://henry.precheur.org'
BLOG_DESCRIPTION = 'Biodegradable pollution for the web: Python, OpenBSD, &'
'blah blah blah'

env = Environment(loader=FileSystemLoader('templates/'), trim_blocks=True)

POST_DIR = 'posts/'
OUTPUT_DIR = 'output/'

post_list = set()
for post in os.listdir(POST_DIR):
    if post.endswith('.html'):
        p = Post(os.path.join(POST_DIR, post))
        if p in post_list:
# FIXME nobody is gonna understand this ...
            raise IOError('%s already parsed (duplicated date / title ?)' %
                    p.title)
        else:
            post_list.add(p)

tmpl = env.get_template('index.html.tmpl')

output = file(os.path.join(OUTPUT_DIR, 'index.html'), 'w')
output.write(tmpl.render(title=BLOG_TITLE, post_list=reversed(sorted(post_list))))

post_tmpl = env.get_template('post.html.tmpl')
# build post individual page
for post in post_list:
    def make_dir(dir):
        if os.path.exists(dir):
            if not os.path.isdir(dir):
                raise IOError('%s exists and is not a directory' % dir)
        else:
            print 'making %s' % dir
            os.mkdir(dir)
    dir = 'output'
    for d in (post.date.year, post.date.month, post.date.day, post.title):
        dir = os.path.join(dir, str(d))
        make_dir(dir)
    filename = os.path.join(dir, 'index.html')
    if os.path.exists(filename):
        if not os.path.isfile(filename):
            raise IOError('%s exists and is not a file' % filename)
    output = file(filename, 'w')
    output.write(post_tmpl.render(post=post))

def generate_rss(post_list, filename):
    rss_items = []
    for post in reversed(sorted(post_list)):
        rss_items.append(
                PyRSS2Gen.RSSItem(
                    title=post.title,
                    link=post.url(prefix=BLOG_BASE_URL),
                    description=post.content,
                    guid=post.url(prefix=BLOG_BASE_URL),
                    pubDate=datetime.datetime(*(post.date.timetuple()[:3]))))

    rss = PyRSS2Gen.RSS2(
        title = BLOG_TITLE,
        link = BLOG_BASE_URL,
        description = "The latest news about PyRSS2Gen, a "
                      "Python library for generating RSS2 feeds",
        lastBuildDate = datetime.datetime.now(),
        items=rss_items)

    rss.write_xml(open(filename, "w"))

generate_rss(post_list, os.path.join(OUTPUT_DIR, 'rss.xml'))
