import email
from datetime import date
from time import strptime
from urllib import quote

class Post:
    def __init__(self, filename):
        e = email.message_from_file(open(filename))
        items = e.items()
        for (key, value) in ((key.lower(), value) for (key, value) in e.items()):
            self.__dict__[key] = value
        self._filename = filename
        self.date = self._parse_date(self.date)
        self.content = e.get_payload()

# FIXME prefix & suffix param or members of the class ?
    def url(self, prefix='', suffix='index.html'):
        return "%s%d/%d/%d/%s/index.html" % \
            (prefix, self.date.year, self.date.month, self.date.day,
             quote(self.title))

    @staticmethod
    def _parse_date(date_):
        date_fmt_list = ['%Y-%m-%d', '%y-%m-%d', '%m/%d/%Y', '%m/%d/%y',
            '%d/%m/%y', '%d/%m/%Y']
        date_tuple = None
        for date_fmt in date_fmt_list:
            try:
                date_tuple = strptime(date_, date_fmt)
                break
            except ValueError:
                continue
        if date_tuple is None:
            raise ValueError('unable to parse date %r '
                    '(use %YYYY-MM-DD %format)' % (date_))
        return date(*date_tuple[0:3])

    def __cmp__(self, other):
        c = cmp(self.date, other.date)
        if c == 0:
            return cmp(self.title, other.title)
        else:
            return c

    def __hash__(self):
        return hash(self.date)
