import os
import shutil
import tempfile
import unittest
import StringIO
import email
import datetime
from optparse import Values

from weblog import Post, PostError, jinja_environment
from weblog.publish import load_post_list, generate_rss, generate_index_listing
from weblog.date import command_date
from weblog.publish import command_publish

class TestSimpleLoad(unittest.TestCase):

    def test_load_post_list(self):
        post_list = load_post_list('test/simple/')
        self.assertEqual(len(post_list), 3)
        sorted_list = sorted(post_list)
        self.assertEqual(sorted_list[0].title, 'post1')
        self.assertEqual(sorted_list[1].title, 'post2')
        self.assertEqual(sorted_list[2].title, 'post3')

    def test_load_post_list_encoding_failure(self):
        Post.DEFAULT_ENCODING = 'ascii'
        self.assertRaises(PostError, load_post_list, 'test/encoding/')
    
    def test_load_post_list_encoding(self):
        Post.DEFAULT_ENCODING = 'UTF-8'
        post_list = load_post_list('test/encoding/')
        self.assertEqual(len(post_list), 2)
        sorted_list = sorted(post_list)
        self.assertEqual(sorted_list[0].title,
                         'UTF-8 post &#214;&#201;&#200;&#196; ...')
        self.assertEqual(sorted_list[0].content,
                         '&#214;&#233;&#232;&#228;\n')
        self.assertEqual(sorted_list[1].title,
                         'latin post &#214;&#201;&#200;&#196; ...')
        self.assertEqual(sorted_list[1].content,
                         '&#214;&#233;&#232;&#228;\n')


class TestJinja(unittest.TestCase):

    env = jinja_environment(os.path.dirname(__file__))

    def test_render_string(self):
        template = self.env.\
                from_string('Hello {{ string_template|renderstring }}!')
        self.assertEqual(template.render(dict(string_template='{{ foo }} world',
                                              foo='crazy')),
                         u'Hello crazy world!')

    def test_format_date_(self):
        template = self.env.from_string('{{ d|format_date }}')
        self.assertEqual(template.render(dict(d=datetime.date(2008, 7, 21))),
                         '2008-07-21')
        self.assertEqual(template.render(dict(d=datetime.datetime(2008, 7, 21,
                                                                  21, 42, 12,
                                                                  123))),
                         '2008-07-21 21:42:12')
        self.assertRaises(TypeError, template.render, dict(d=12))


class TestGeneration(unittest.TestCase):

    env = jinja_environment(os.path.dirname(__file__))

    def setUp(self):
        self.tempdir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tempdir)

    def test_generate_listing_empty(self):
        generate_index_listing(10,
                               self.tempdir,
                               self.env.get_template('index.html.tmpl'),
                               list(),
                               dict(title='test',
                                    url='http://test.net',
                                    description='test'))

    def test_generate_listing(self):
        post1 = '''title: post1
date: 2008-02-04

post 1'''
        post2 = '''title: post2
date: 2008-01-18
author: test@test.com

post 2'''
        post_list = [Post(StringIO.StringIO(post1)),
                     Post(StringIO.StringIO(post2))]
        generate_index_listing(10,
                               self.tempdir,
                               self.env.get_template('index.html.tmpl'),
                               post_list,
                               dict(title='test',
                                    url='http://test.net',
                                    description='test'))

    def test_generate_rss(self):
        post1 = '''title: post1
date: 2008-02-04

post 1'''
        post2 = '''title: post2
date: 2008-01-18
author: test@test.com

post 2
<a href='test.html'>'''
        post_list = [Post(StringIO.StringIO(post1)),
                     Post(StringIO.StringIO(post2))]
        generate_rss(post_list,
                     os.path.join(self.tempdir, 'rss.xml'),
                     dict(title='test',
                          url='http://test.net',
                          description='test'))

    def test_generate_rss_empty(self):
        generate_rss(list(),
                     os.path.join(self.tempdir, 'rss.xml'),
                     dict(title='test',
                          url='http://test.net',
                          description='test'))

    def test_date(self):
        filename = os.path.join(self.tempdir, 'set_date.html')
        # First test a message without any date defined
        def file_without_date():
            file(filename, 'w').write('title: Some title\n\nSome content')
        file_without_date()
        command_date([filename, '2008-1-1'], None)
        message = email.message_from_file(file(filename))
        self.assert_('date' in message)
        self.assertEqual(message['date'], str(datetime.date(2008, 1, 1)))
        # Then test a file which has already a date
        def file_with_date():
            file(filename, 'w').write('title: Some title\ndate: 2008-12-31\n'
                                      '\nSome content')
        file_with_date()
        command_date([filename, '2008-1-1'], None)
        message = email.message_from_file(file(filename))
        self.assert_('date' in message)
        self.assertEqual(message['date'], str(datetime.date(2008, 1, 1)))
        # Test aliases
        for alias in ('now', 'today', 'tomorrow', 'next_day'):
            file_without_date()
            command_date([filename, alias], None)
            message = email.message_from_file(file(filename))
            self.assert_('date' in message)

    def _test_publish(self, dirname):
        options = Values(dict(source_dir=os.path.join(os.path.dirname(__file__),
                                                      'test', dirname),
                              output_dir=self.tempdir,
                              configuration_file='weblog.ini',
                              debug=False))
        command_publish(None, options)

    def test_publish_empty(self):
        self._test_publish('empty')

    def test_publish_encoding(self):
        self._test_publish('encoding')

    def test_publish_full_url(self):
        self._test_publish('full_url')

    def test_publish_simple(self):
        self._test_publish('simple')

if __name__ == '__main__':
    import nose
    nose.main()
