#!/usr/bin/env python
import imp
from os import path

filename = path.join(path.dirname(__file__), 'bin', 'weblog')
module = imp.load_module('weblog_executable', file(filename), filename,
                         ('', 'r', imp.PY_SOURCE))
module.main()
