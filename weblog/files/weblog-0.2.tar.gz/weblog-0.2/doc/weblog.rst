Weblog manual
=============
:Author: Henry Precheur <henry@precheur.org>
:Reviewers: Anis Kadri, Eric Salama

Abstract
--------
Weblog is a weblog or blog publisher. It takes some files as input and outputs
some static HTML / RSS. Weblog aims to be simple and robust.

Installation
------------

Download Weblog's latest version at http://henry.precheur.org/weblog/.

Extract it::

  tar zxf weblog.tar.gz

It can be used right away.

You can also install it using the supplied ``setup.py`` script. Simply type
``python setup.py --help`` to learn how to use it.

Make a post
-----------

``$WEBLOG`` represents to weblog installation directory.

Create a new directory named ``my_blog`` for example (the $ sign represents the shell prompt, do not type it!)::

  $ mkdir my_blog

Then copy from the weblog installation directory the file ``weblog.ini`` into ``my_blog``::

  $ cp $WEBLOG/example/weblog.ini my_blog

The file ``weblog.ini`` contains the parameters of the weblog. Check the Configuration file section for more information.

Then create a file named ``first_post.html`` in the my_blog directory containing::

  title: First post
  author: Me
  date: 2007-08-25
  
  Hello world!

Then type in the ``my_blog`` directory::

  $ python $WEBLOG/weblog_publish.py

It should create a directory named ``output`` which contains the generated
files. You can look at the results by opening the file ``output/index.html`` in
your browser.

The first 3 lines of the file ``first_post.html`` define the parameters of the
post. These are standard :RFC:`2822` headers (the headers used in Emails).
These 3 parameters are mandatory. There is no additional parameter actually.

The line ``Hello world!`` is the actual content of the post. Note that the
blank line between the headers and the content is required.

The content is an HTML block. It means that you can use the HTML syntax to
format your post content. For example create a second file named
``second_post.html``::

  title: Second post
  author: Me (again!)
  date: 2007-08-26
  
  <em>Second</em> <quote>test</quote> <strong>post</strong>!
  <p>
  The author lastname is Pr&ecirc;cheur
  </p>

Regenerate the weblog files::

  $ python $WEBLOG/weblog_publish.py

You should see a second post with some funny formating.

Actually all the post filenames must end with ``.html``.

Configuration file
------------------

All configuration options are in the ``weblog`` section. To learn more about the format of the configuration file http://docs.python.org/lib/module-ConfigParser.html.

A configuration file looks like this::

  [weblog]
  title: Blog's title
  url: http://example.com/
  description: A sample blog.
  post_dir: path/to/my/posts
  output_dir: path/to/output/directory

Fields description
~~~~~~~~~~~~~~~~~~

title
  The title of the blog. It appears at the top of the blog's homepage and in the page's title

  This field is mandatory.

url
  The base url of your blog. For example ``http://my-host.com/my-weblog/``. It is used to generate the absolute URL's to your weblog.

  This field is mandatory.

description
  A short description of your weblog. Like "My favorite books reviews", or "Dr. Spock, publications about electronics".
  Note that is possible to use multiple lines like this::

    description: My weblog
      about
        configuration files.

  But the description will be merged to a single line like this "My weblog about configuration files.".

  This field is mandatory.

post_dir
  The path to your post files. By default the current directory.

output_dir
  The directory where generated files will be put. By default ``output``.
