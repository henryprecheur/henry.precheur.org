import os
import sys
import datetime
from ConfigParser import SafeConfigParser, NoOptionError
from jinja import Environment, FileSystemLoader, PackageLoader, ChoiceLoader
from weblog import RSS2, RSSItem
from weblog import Post

def build_env():
    TEMPLATE_DIR = 'templates'
    fs_loader = FileSystemLoader(TEMPLATE_DIR)
    fs_app_loader = FileSystemLoader(os.path.join(sys.path[0], 'weblog', TEMPLATE_DIR))
    pkg_loader = PackageLoader('weblog', TEMPLATE_DIR)
    choice_loader = ChoiceLoader([fs_loader, fs_app_loader, pkg_loader])
    return Environment(loader=choice_loader, trim_blocks=True)

def build_post_list(path):
    post_list = set()
    for post in os.listdir(path):
        if post.endswith('.html'):
            p = Post(os.path.join(path, post))
            if p in post_list:
# FIXME nobody is gonna understand this ...
                raise IOError('"%s" already parsed (duplicated date / title ?)' %
                        p.title)
            else:
                post_list.add(p)
    return post_list

def generate_rss(post_list, filename, title, base_url):
    rss_items = []
    for post in reversed(sorted(post_list)):
        rss_items.append(
                RSSItem(
                    title=post.title,
                    link=post.url(prefix=base_url),
                    description=post.content,
                    guid=post.url(prefix=base_url),
                    pubDate=datetime.datetime(*(post.date.timetuple()[:3]))))
    rss = RSS2(
        title = title,
        link = base_url,
        description = "The latest news about PyRSS2Gen, a "
                      "Python library for generating RSS2 feeds",
        lastBuildDate = datetime.datetime.now(),
        items=rss_items)
    rss.write_xml(open(filename, "w"))

def main():
#first load config file
    CONFIG_FILE = 'weblog.ini'
    if not os.path.exists(CONFIG_FILE):
        print 'unable to find file %s' % CONFIG_FILE
        exit(1)
    config = SafeConfigParser()
    config.read(CONFIG_FILE)
    config_dict = dict(config.items('weblog'))

    try:
        BLOG_TITLE = config_dict['title']
        blog_base_url = config_dict['url']
        if blog_base_url and not blog_base_url.endswith('/'):
            blog_base_url += '/'
        BLOG_DESCRIPTION = config_dict['description']
        POST_DIR = config_dict.get('post_dir', '.')
        OUTPUT_DIR = config_dict.get('output_dir', 'output/')
    except KeyError, e:
        print 'Unable to find %s in configuration file %s' % (e, CONFIG_FILE)
        exit(1)

    if not os.path.exists(OUTPUT_DIR):
        print 'creating %s ...' % OUTPUT_DIR
        os.mkdir(OUTPUT_DIR)

    env = build_env()

    post_list = build_post_list(POST_DIR)
    tmpl = env.get_template('index.html.tmpl')

    output = file(os.path.join(OUTPUT_DIR, 'index.html'), 'w')
    output.write(tmpl.render(title=BLOG_TITLE,
                base_url=blog_base_url,
                post_list=reversed(sorted(post_list))))

    post_tmpl = env.get_template('post.html.tmpl')

# build post individual page
    for post in post_list:
        def make_dir(dir):
            if os.path.exists(dir):
                if not os.path.isdir(dir):
                    raise IOError('%s exists and is not a directory' % dir)
            else:
                print 'making %s' % dir
                os.mkdir(dir)
        dir = 'output'
        for d in (post.date.year, post.date.month, post.date.day, post.title):
            dir = os.path.join(dir, str(d))
            make_dir(dir)
        filename = os.path.join(dir, 'index.html')
        if os.path.exists(filename):
            if not os.path.isfile(filename):
                raise IOError('%s exists and is not a file' % filename)
        output = file(filename, 'w')
        output.write(post_tmpl.render(title=post.title,
                                      base_url=blog_base_url,
                                      post=post))

    generate_rss(post_list, os.path.join(OUTPUT_DIR, 'rss.xml'),
                 BLOG_TITLE, blog_base_url)

if __name__ == '__main__':
    main()
