from setuptools import setup, find_packages
setup(
    name = "weblog",
    version = "0.2",
    packages = ['weblog'],
    package_data={'weblog': ['templates/*.tmpl']},
    scripts = ['weblog_publish.py'],

    install_requires = ['Jinja>=1.1'],

    data_files=[('doc', ['doc/weblog.rst'])],
# unzip the egg so we can access to documentation & templates
    zip_safe = False,

    # metadata for upload to PyPI
    author = "Henry Precheur",
    author_email = "henry@precheur.org",
    description = "Weblog is a minimal Blog engine. It outputs static HTML / RSS files",
    license = "ISC",
    keywords = "weblog blog journal rss",
    url = "http://henry.precheur.org/",
)
